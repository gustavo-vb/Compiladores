int main() {
	int aux,cont,a, teste;
	a = 10;
	aux = a;
	
	if (1) 
	  teste = 'c';
    endif
	  
	if (0)
	  a = a + 1;
	else
	  a = a - 1;
	endif
}
