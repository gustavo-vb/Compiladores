//conteudo foi movido pq nao estava compilando por erro de importacao
#ifndef TABSIMB_H
#define TABSIMB_H

#include <string.h>
#include "tipos.h"

#define MAX 1000

struct symbol {
	char nome[50];
	int tam;
	int tipo;
	float valor;
	int num_param;
};

extern int offset;
extern int proximo_elem;
extern struct symbol Tabela[MAX];

int procura(char *nome);
int insere(char *nome);
int set_type(int pos, int tipo);
int set_num_param(int pos, int num_param);
int param_args_diferentes(int pos_func, int num_args);
char *obtemNome(int pos);
void imprime();

#endif