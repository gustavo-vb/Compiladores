main() {
	int x,y;
	z;
	~
	while(y > 10) {
		return k;
	}
}
