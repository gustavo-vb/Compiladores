#define NUM 256
#define ID 257
#define INT 258
#define GE 259
#define IF 260
