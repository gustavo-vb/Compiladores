#ifndef TIPOS_H
#define TIPOS_H

int retorna_maior_tipo(int tipo1, int tipo2);
int get_tam_tipo(int tipo);
int tipos_inconsistentes_atrib(int tipo1, int tipo2);

#endif